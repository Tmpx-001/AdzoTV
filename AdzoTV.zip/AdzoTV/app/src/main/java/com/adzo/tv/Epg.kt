package com.adzo.tv

import android.content.Context
import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.zip.GZIPInputStream

data class Programme(val start: Long, val stop: Long, val title: String, val desc: String?) {
    fun progress(now: Long = System.currentTimeMillis()): Int =
        if (stop <= start) 0 else (((now - start) * 100) / (stop - start)).toInt().coerceIn(0, 100)
}

/**
 * Guide des programmes au format XMLTV :
 *
 *   <channel id="TF1.fr"><display-name>TF1</display-name></channel>
 *   <programme start="20261021103000 +0200" stop="20261021111500 +0200" channel="TF1.fr">
 *     <title>Le journal</title><desc>…</desc>
 *   </programme>
 *
 * Le fichier est lu en flux (il peut peser 50 Mo+) et on ne garde en mémoire que les
 * chaînes présentes dans la playlist, sur une fenêtre de -1 h à +36 h.
 */
object Epg {
    private const val MAX_AGE_MS = 12 * 3600_000L      // re-télécharge au bout de 12 h
    private const val KEEP_BEFORE_MS = 3600_000L
    private const val KEEP_AFTER_MS = 36 * 3600_000L

    /** clé = id EPG (en minuscules) */
    @Volatile private var programmes: Map<String, List<Programme>> = emptyMap()
    /** nom normalisé -> id EPG, pour les playlists sans tvg-id */
    @Volatile private var nameIndex: Map<String, String> = emptyMap()

    val isLoaded get() = programmes.isNotEmpty()

    private fun cacheFile(ctx: Context) = File(ctx.filesDir, "epg.xml")

    fun clearCache(ctx: Context) {
        cacheFile(ctx).delete()
        programmes = emptyMap(); nameIndex = emptyMap()
    }

    /** @return nombre de chaînes de la playlist qui ont un guide */
    suspend fun load(ctx: Context, url: String, channels: List<Channel>, force: Boolean): Int =
        withContext(Dispatchers.IO) {
            val cache = cacheFile(ctx)
            val stale = !cache.exists() || cache.length() == 0L ||
                System.currentTimeMillis() - cache.lastModified() > MAX_AGE_MS
            if (force || stale) {
                val tmp = File(ctx.filesDir, "epg.tmp")
                try {
                    Store.downloadTo(url, tmp)
                    tmp.renameTo(cache)
                } catch (e: Exception) {
                    tmp.delete()
                    if (!cache.exists()) throw e   // sinon on garde l'ancien guide
                }
            }
            parse(openMaybeGzip(cache), channels)
            channels.count { find(it) != null }
        }

    // ---------- Requêtes ----------

    private fun find(ch: Channel): List<Programme>? {
        ch.tvgId?.lowercase()?.let { id -> programmes[id]?.let { return it } }
        val id = nameIndex[normalize(ch.name)] ?: return null
        return programmes[id]
    }

    /** Programme en cours et suivant. */
    fun nowNext(ch: Channel, now: Long = System.currentTimeMillis()): Pair<Programme?, Programme?> {
        val list = find(ch) ?: return null to null
        val i = list.indexOfFirst { it.stop > now }
        if (i < 0) return null to null
        val cur = list[i].takeIf { it.start <= now }
        val next = if (cur != null) list.getOrNull(i + 1) else list[i]
        return cur to next
    }

    // ---------- Lecture du XML ----------

    private fun openMaybeGzip(file: File): InputStream {
        val bis = BufferedInputStream(file.inputStream(), 64 * 1024)
        bis.mark(2)
        val b1 = bis.read(); val b2 = bis.read()
        bis.reset()
        return if (b1 == 0x1f && b2 == 0x8b) GZIPInputStream(bis, 64 * 1024) else bis
    }

    private fun parse(input: InputStream, channels: List<Channel>) {
        val wantedIds = channels.mapNotNull { it.tvgId?.lowercase() }.toHashSet()
        val wantedNames = channels.map { normalize(it.name) }.toHashSet()
        val now = System.currentTimeMillis()
        val from = now - KEEP_BEFORE_MS
        val to = now + KEEP_AFTER_MS

        val keepIds = HashSet<String>(wantedIds)
        val names = HashMap<String, String>()
        val result = HashMap<String, MutableList<Programme>>()
        val formats = listOf(
            SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US),
            SimpleDateFormat("yyyyMMddHHmmss", Locale.US)
        )

        input.use { stream ->
            val p = Xml.newPullParser()
            p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            p.setInput(stream, null)

            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) when (p.name) {
                    "channel" -> {
                        val id = p.getAttributeValue(null, "id")?.lowercase()
                        val displayNames = ArrayList<String>()
                        readChildren(p, NAME_TAGS) { _, text -> displayNames += text }
                        if (id != null) for (dn in displayNames) {
                            val n = normalize(dn)
                            if (n in wantedNames) { keepIds += id; names.putIfAbsent(n, id) }
                        }
                    }
                    "programme" -> {
                        val id = p.getAttributeValue(null, "channel")?.lowercase()
                        if (id != null && id in keepIds) {
                            val start = parseTime(p.getAttributeValue(null, "start"), formats)
                            val stop = parseTime(p.getAttributeValue(null, "stop"), formats)
                            if (start != null && stop != null && stop > from && start < to) {
                                var title: String? = null; var desc: String? = null
                                readChildren(p, PROG_TAGS) { tag, text ->
                                    if (tag == "title" && title == null) title = text
                                    if (tag == "desc" && desc == null) desc = text
                                }
                                result.getOrPut(id) { ArrayList() } +=
                                    Programme(start, stop, title ?: "Sans titre", desc)
                            }
                        }
                    }
                }
                ev = p.next()
            }
        }
        result.values.forEach { it.sortBy { prog -> prog.start } }
        programmes = result
        nameIndex = names
    }

    private val NAME_TAGS = setOf("display-name")
    private val PROG_TAGS = setOf("title", "desc")

    /**
     * Parcourt le contenu de la balise courante jusqu'à sa fermeture.
     * Seules les balises de [wanted] sont lues ; le reste (credits, icon…) est sauté.
     */
    private inline fun readChildren(p: XmlPullParser, wanted: Set<String>, onChild: (String, String) -> Unit) {
        var depth = 1
        while (depth > 0) {
            when (p.next()) {
                XmlPullParser.START_TAG ->
                    if (depth == 1 && p.name in wanted) {
                        val tag = p.name
                        val text = try { p.nextText().trim() } catch (_: Exception) { "" }
                        // nextText() s'arrête sur la balise fermante de l'enfant : la profondeur ne bouge pas
                        if (p.eventType == XmlPullParser.END_TAG) onChild(tag, text) else depth++
                    } else depth++
                XmlPullParser.END_TAG -> depth--
                XmlPullParser.END_DOCUMENT -> return
            }
        }
    }

    private fun parseTime(s: String?, formats: List<SimpleDateFormat>): Long? {
        if (s.isNullOrBlank()) return null
        val v = s.trim()
        for (f in formats) {
            try { return f.parse(v)?.time } catch (_: Exception) {}
        }
        return null
    }

    private val reMarks = Regex("\\p{M}+")
    private val reBrackets = Regex("""\[[^\]]*\]|\([^)]*\)""")              // [..] (..)
    private val rePrefix = Regex("""^\s*\|?[a-z]{2,3}\s*[|:]\s*""")          // "FR:" "|FR|"
    private val reQuality = Regex("""\b(uhd|fhd|hd|sd|hevc|h265|4k|8k|1080p?|720p?|backup|vip)\b""")
    private val reNonAlnum = Regex("[^a-z0-9+]")

    /** "FR: TF1 FHD" et "TF1 HD" -> "tf1" */
    fun normalize(name: String): String {
        var s = Normalizer.normalize(name.lowercase(), Normalizer.Form.NFD).replace(reMarks, "")
        s = s.replace(reBrackets, " ").replace(rePrefix, " ").replace(reQuality, " ")
        return s.replace(reNonAlnum, "")
    }
}

package com.adzo.tv

import android.app.Application
import android.content.Context
import android.os.Build
import java.io.File

/**
 * Enregistre tout plantage dans un fichier : au lancement suivant, l'appli l'affiche
 * au lieu de replanter en boucle (et on peut me l'envoyer pour corriger).
 */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, e ->
            try {
                crashFile(this).writeText(
                    "ADZO TV ${BuildConfig.VERSION_NAME} · Android ${Build.VERSION.RELEASE} · ${Build.MANUFACTURER} ${Build.MODEL}\n\n" +
                        e.stackTraceToString().take(6000)
                )
            } catch (_: Throwable) {}
            previous?.uncaughtException(thread, e)
        }
    }

    companion object {
        fun crashFile(ctx: Context) = File(ctx.filesDir, "crash.txt")
    }
}

package com.adzo.tv

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load

class GroupAdapter(
    private val onFocusOrClick: (String) -> Unit
) : RecyclerView.Adapter<GroupAdapter.VH>() {

    private var items: List<Pair<String, Int>> = emptyList()
    var selected: String? = null
        private set

    fun submit(list: List<Pair<String, Int>>, select: String?) {
        items = list; selected = select; notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.groupName)
        val count: TextView = v.findViewById(R.id.groupCount)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_group, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val (name, count) = items[pos]
        h.name.text = name
        h.count.text = if (count >= 0) count.toString() else ""
        h.itemView.isActivated = name == selected
        val select = {
            if (selected != name) {
                selected = name
                // Met à jour la surbrillance directement sur les lignes visibles (pas de notify*)
                (h.itemView.parent as? RecyclerView)?.let { rv ->
                    for (i in 0 until rv.childCount) {
                        val child = rv.getChildAt(i)
                        val vh = rv.getChildViewHolder(child) as? VH ?: continue
                        child.isActivated = vh.name.text == name
                    }
                }
                onFocusOrClick(name)
            }
        }
        h.itemView.setOnClickListener { select() }
        // À la télécommande : la catégorie s'ouvre dès qu'on passe dessus (après la mise en page)
        h.itemView.setOnFocusChangeListener { v, has -> if (has) v.post { if (v.hasFocus()) select() } }
    }
}

class ChannelAdapter(
    private val onClick: (Channel, Int) -> Unit,
    private val onLongClick: (Channel, Int) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {

    var items: List<Channel> = emptyList()
        private set
    private var favs: Set<String> = emptySet()

    fun submit(list: List<Channel>, favorites: Set<String>) {
        items = list; favs = favorites; notifyDataSetChanged()
    }

    fun updateFavorites(favorites: Set<String>, pos: Int) {
        favs = favorites; notifyItemChanged(pos)
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val logo: ImageView = v.findViewById(R.id.logo)
        val name: TextView = v.findViewById(R.id.channelName)
        val number: TextView = v.findViewById(R.id.channelNumber)
        val star: TextView = v.findViewById(R.id.star)
        val epgRow: View = v.findViewById(R.id.epgRow)
        val epgTitle: TextView = v.findViewById(R.id.epgTitle)
        val epgProgress: ProgressBar = v.findViewById(R.id.epgProgress)
    }

    /** Met à jour uniquement l'EPG (sans reconstruire les lignes : la sélection télécommande reste en place). */
    fun refreshEpg() = notifyItemRangeChanged(0, items.size, PAYLOAD_EPG)

    override fun onBindViewHolder(h: VH, pos: Int, payloads: MutableList<Any>) {
        if (payloads.contains(PAYLOAD_EPG)) bindEpg(h, items[pos]) else onBindViewHolder(h, pos)
    }

    private fun bindEpg(h: VH, ch: Channel) {
        val (now, next) = Epg.nowNext(ch)
        when {
            now != null -> {
                h.epgTitle.text = now.title
                h.epgProgress.progress = now.progress()
                h.epgProgress.visibility = View.VISIBLE
                h.epgRow.visibility = View.VISIBLE
            }
            next != null -> {
                h.epgTitle.text = "${formatTime(next.start)}  ${next.title}"
                h.epgProgress.visibility = View.GONE
                h.epgRow.visibility = View.VISIBLE
            }
            else -> h.epgRow.visibility = View.GONE
        }
    }

    companion object { private const val PAYLOAD_EPG = "epg" }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_channel, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val ch = items[pos]
        h.name.text = ch.name
        h.number.text = (pos + 1).toString()
        h.star.visibility = if (ch.url in favs) View.VISIBLE else View.INVISIBLE
        bindEpg(h, ch)
        h.logo.load(ch.logo) {
            crossfade(true)
            placeholder(R.drawable.logo_placeholder)
            error(R.drawable.logo_placeholder)
        }
        h.itemView.setOnClickListener { onClick(ch, h.bindingAdapterPosition) }
        h.itemView.setOnLongClickListener { onLongClick(ch, h.bindingAdapterPosition); true }
    }
}

private val timeFmt = java.text.SimpleDateFormat("HH:mm", java.util.Locale.FRANCE)
fun formatTime(ms: Long): String = timeFmt.format(java.util.Date(ms))

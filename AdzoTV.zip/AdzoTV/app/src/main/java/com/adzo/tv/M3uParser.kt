package com.adzo.tv

data class Channel(
    val name: String,
    val url: String,
    val group: String,
    val logo: String?,
    val tvgId: String?,
    val userAgent: String?
)

/**
 * Lit une playlist M3U / M3U8 "étendue" :
 *
 *   #EXTM3U
 *   #EXTINF:-1 tvg-id="tf1.fr" tvg-logo="http://..." group-title="France",TF1
 *   #EXTVLCOPT:http-user-agent=Mozilla/5.0
 *   http://serveur/live/user/pass/1234.ts
 */
data class Playlist(val channels: List<Channel>, val epgUrl: String?)

object M3uParser {

    private val attrRegex = Regex("""([\w-]+)="([^"]*)"""")

    /** Films et séries des serveurs Xtream : énormes listes, inutiles pour la télé en direct. */
    private fun isVod(url: String) = url.contains("/movie/") || url.contains("/series/")

    fun parse(text: String): Playlist = parse(text.lineSequence())

    fun parse(lines: Sequence<String>): Playlist {
        val channels = ArrayList<Channel>()
        var epgUrl: String? = null
        var pendingName: String? = null
        var pendingAttrs: Map<String, String> = emptyMap()
        var pendingGroup: String? = null
        var pendingUa: String? = null

        lines.forEach { raw ->
            val line = raw.trim()
            when {
                line.isEmpty() -> Unit

                // En-tête : #EXTM3U url-tvg="http://…/epg.xml.gz"
                line.startsWith("#EXTM3U", ignoreCase = true) -> {
                    val attrs = attrRegex.findAll(line)
                        .associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                    epgUrl = (attrs["url-tvg"] ?: attrs["x-tvg-url"] ?: attrs["tvg-url"])
                        ?.split(',')?.firstOrNull()?.trim()?.takeIf { it.startsWith("http") }
                }

                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    // Le nom est après la DERNIÈRE virgule hors guillemets
                    val commaIdx = lastCommaOutsideQuotes(line)
                    pendingName = if (commaIdx >= 0) line.substring(commaIdx + 1).trim() else "Sans nom"
                    val header = if (commaIdx >= 0) line.substring(0, commaIdx) else line
                    pendingAttrs = attrRegex.findAll(header)
                        .associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                }

                line.startsWith("#EXTGRP:", ignoreCase = true) ->
                    pendingGroup = line.substringAfter(":").trim()

                line.startsWith("#EXTVLCOPT:http-user-agent=", ignoreCase = true) ->
                    pendingUa = line.substringAfter("=").trim()

                line.startsWith("#") -> Unit // autres directives ignorées

                else -> {
                    // Ligne = URL du flux
                    if (isVod(line)) {
                        pendingName = null; pendingAttrs = emptyMap(); pendingGroup = null; pendingUa = null
                        return@forEach
                    }
                    val name = pendingName ?: line.substringAfterLast('/')
                    val group = pendingAttrs["group-title"]?.takeIf { it.isNotBlank() }
                        ?: pendingGroup ?: "Sans catégorie"
                    channels += Channel(
                        name = name.ifBlank { "Sans nom" },
                        url = line,
                        group = group,
                        logo = pendingAttrs["tvg-logo"]?.takeIf { it.isNotBlank() },
                        tvgId = pendingAttrs["tvg-id"]?.takeIf { it.isNotBlank() },
                        userAgent = pendingAttrs["user-agent"] ?: pendingUa
                    )
                    pendingName = null; pendingAttrs = emptyMap(); pendingGroup = null; pendingUa = null
                }
            }
        }
        return Playlist(channels, epgUrl)
    }

    private fun lastCommaOutsideQuotes(s: String): Int {
        var inQuotes = false
        var last = -1
        s.forEachIndexed { i, c ->
            if (c == '"') inQuotes = !inQuotes
            else if (c == ',' && !inQuotes) last = i
        }
        return last
    }
}

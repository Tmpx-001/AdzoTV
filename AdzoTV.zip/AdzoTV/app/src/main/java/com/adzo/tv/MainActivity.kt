package com.adzo.tv

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var setupPanel: View
    private lateinit var contentPanel: View
    private lateinit var urlInput: EditText
    private lateinit var search: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var groupsList: RecyclerView
    private lateinit var channelsList: RecyclerView

    private lateinit var groupAdapter: GroupAdapter
    private lateinit var channelAdapter: ChannelAdapter

    private var allChannels: List<Channel> = emptyList()
    private var currentGroup: String = Store.ALL
    private var epgJob: Job? = null
    private var tickerJob: Job? = null

    // ---------- Films / séries (API Xtream) ----------
    private enum class Mode { LIVE, MOVIES, SERIES }
    private var mode = Mode.LIVE
    private lateinit var modeButtons: Map<Mode, Button>
    private var account: XtreamAccount? = null
    private var categories: List<Category> = emptyList()
    private var vodItems: List<Channel> = emptyList()
    private var currentCategory: Category? = null
    private var openedSeries: Channel? = null
    private var seriesBackup: List<Channel> = emptyList()
    private var vodJob: Job? = null
    private val vodCache = LinkedHashMap<String, List<Channel>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupPanel = findViewById(R.id.setupPanel)
        contentPanel = findViewById(R.id.contentPanel)
        urlInput = findViewById(R.id.urlInput)
        search = findViewById(R.id.search)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        groupsList = findViewById(R.id.groupsList)
        channelsList = findViewById(R.id.channelsList)

        groupAdapter = GroupAdapter { group ->
            if (mode == Mode.LIVE) { currentGroup = group; showChannels() } else selectCategory(group)
        }
        channelAdapter = ChannelAdapter(
            onClick = { ch, pos -> if (ch.url.startsWith(Xtream.SERIES_SCHEME)) openSeries(ch) else play(pos) },
            onLongClick = { ch, pos ->
                val added = Store.toggleFavorite(this, ch.url)
                channelAdapter.updateFavorites(Store.favorites(this), pos)
                toast(if (added) "Ajoutée aux favoris" else "Retirée des favoris")
                if (mode == Mode.LIVE) refreshGroups()
            }
        )
        groupsList.layoutManager = LinearLayoutManager(this)
        groupsList.adapter = groupAdapter
        channelsList.layoutManager = LinearLayoutManager(this)
        channelsList.adapter = channelAdapter

        findViewById<Button>(R.id.loadButton).setOnClickListener { submitUrl() }
        urlInput.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE || id == EditorInfo.IME_ACTION_GO) { submitUrl(); true } else false
        }
        findViewById<Button>(R.id.refreshButton).setOnClickListener {
            vodCache.clear(); load(forceRefresh = true)
        }
        modeButtons = mapOf(
            Mode.LIVE to findViewById<Button>(R.id.modeLive),
            Mode.MOVIES to findViewById<Button>(R.id.modeMovies),
            Mode.SERIES to findViewById<Button>(R.id.modeSeries)
        )
        modeButtons.forEach { (m, b) -> b.setOnClickListener { switchMode(m) } }
        modeButtons.getValue(Mode.LIVE).isActivated = true

        // Retour : depuis les épisodes d'une série, revient à la liste des séries
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!closeSeries()) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })
        findViewById<Button>(R.id.settingsButton).setOnClickListener { askChangeUrl() }

        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = showChannels()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })

        val crash = App.crashFile(this)
        when {
            crash.exists() -> showCrash(crash.readText().also { crash.delete() })
            Store.playlistUrl(this) == null -> showSetup()
            else -> load(forceRefresh = false)
        }
    }

    /** Après un plantage : on affiche l'erreur au lieu de recharger (et replanter) en boucle. */
    private fun showCrash(report: String) {
        showSetup()
        AlertDialog.Builder(this)
            .setTitle("L'appli a planté")
            .setMessage("Prends cet écran en photo pour le correctif :\n\n" + report.take(1500))
            .setCancelable(false)
            .setPositiveButton("Réessayer") { _, _ ->
                if (Store.playlistUrl(this) != null) load(forceRefresh = false)
            }
            .setNegativeButton("Changer de playlist") { _, _ -> Store.clearCache(this); showSetup() }
            .show()
    }

    // ---------- Écrans ----------

    private fun showSetup() {
        setupPanel.visibility = View.VISIBLE
        contentPanel.visibility = View.GONE
        urlInput.setText(Store.playlistUrl(this) ?: "")
        urlInput.requestFocus()
    }

    private fun submitUrl() {
        val url = urlInput.text.toString().trim()
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            toast("L'adresse doit commencer par http:// ou https://"); return
        }
        Store.setPlaylistUrl(this, url)
        Store.clearCache(this)
        load(forceRefresh = true)
    }

    private fun askChangeUrl() {
        val epg = Store.resolveEpgUrl(this)
        AlertDialog.Builder(this)
            .setTitle("Réglages")
            .setMessage("Playlist :\n${Store.playlistUrl(this)}\n\nGuide des programmes :\n${epg ?: "aucun"}")
            .setPositiveButton("Changer la playlist") { _, _ -> showSetup() }
            .setNeutralButton("Adresse du guide") { _, _ -> askEpgUrl() }
            .setNegativeButton("Fermer", null)
            .show()
    }

    /** Pour les playlists qui n'indiquent pas leur guide : on peut saisir l'URL XMLTV à la main. */
    private fun askEpgUrl() {
        val input = EditText(this).apply {
            setText(Store.manualEpgUrl(this@MainActivity) ?: "")
            hint = "http://…/epg.xml(.gz) — vide = automatique"
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("Adresse du guide (XMLTV)")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                Store.setManualEpgUrl(this, input.text.toString().trim())
                loadEpg(force = true)
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    // ---------- Chargement ----------

    private fun load(forceRefresh: Boolean) {
        val url = Store.playlistUrl(this) ?: return showSetup()
        progress.visibility = View.VISIBLE
        status.text = "Chargement de la playlist…"
        lifecycleScope.launch {
            try {
                account = Xtream.fromPlaylistUrl(url)
                allChannels = Store.loadPlaylist(this@MainActivity, url, forceRefresh).channels
                if (allChannels.isEmpty()) {
                    toast("Aucune chaîne trouvée dans ce fichier"); showSetup(); return@launch
                }
                setupPanel.visibility = View.GONE
                contentPanel.visibility = View.VISIBLE
                if (mode == Mode.LIVE) {
                    refreshGroups()
                    showChannels()
                    status.text = "${allChannels.size} chaînes"
                    focusLastChannel()
                } else switchMode(mode)
                loadEpg(forceRefresh)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: OutOfMemoryError) {
                allChannels = emptyList()
                toast("Playlist trop grosse pour cette box")
                showSetup()
            } catch (e: Exception) {
                toast("Impossible de charger : ${e.message}")
                showSetup()
            } finally {
                progress.visibility = View.GONE
            }
        }
    }

    // ---------- Guide des programmes ----------

    private fun loadEpg(force: Boolean) {
        val epgUrl = Store.resolveEpgUrl(this) ?: return
        epgJob?.cancel()
        epgJob = lifecycleScope.launch {
            if (mode == Mode.LIVE) status.text = "${allChannels.size} chaînes · chargement du guide…"
            try {
                val matched = Epg.load(this@MainActivity, epgUrl, allChannels, force)
                if (mode == Mode.LIVE) status.text = "${allChannels.size} chaînes · guide : $matched"
                channelAdapter.refreshEpg()
            } catch (e: Throwable) {   // y compris manque de mémoire : le guide est optionnel
                if (e is kotlinx.coroutines.CancellationException) throw e
                if (mode == Mode.LIVE) status.text = "${allChannels.size} chaînes · guide indisponible"
            }
        }
    }

    /** Fait avancer les barres de progression toutes les minutes. */
    private fun startTicker() {
        tickerJob?.cancel()
        tickerJob = lifecycleScope.launch {
            while (isActive) {
                delay(60_000)
                if (Epg.isLoaded) channelAdapter.refreshEpg()
            }
        }
    }

    override fun onPause() {
        super.onPause()
        tickerJob?.cancel()
    }

    private fun refreshGroups() {
        val favs = Store.favorites(this)
        val groups = mutableListOf<Pair<String, Int>>()
        val favCount = allChannels.count { it.url in favs }
        if (favCount > 0) groups += Store.FAVORITES to favCount
        groups += Store.ALL to allChannels.size
        allChannels.groupingBy { it.group }.eachCount()   // garde l'ordre de la playlist
            .forEach { (g, n) -> groups += g to n }
        if (groups.none { it.first == currentGroup }) currentGroup = Store.ALL
        groupAdapter.submit(groups, currentGroup)
    }

    // ---------- Films & séries ----------

    private fun switchMode(m: Mode) {
        if (m != Mode.LIVE && account == null) {
            toast("Films et séries : il faut un lien Xtream (…/get.php?username=…&password=…)")
            return
        }
        mode = m
        modeButtons.forEach { (k, b) -> b.isActivated = k == m }
        openedSeries = null
        vodJob?.cancel()
        search.setText("")
        if (m == Mode.LIVE) {
            refreshGroups(); showChannels()
            status.text = "${allChannels.size} chaînes"
            return
        }
        val acc = account ?: return
        progress.visibility = View.VISIBLE
        status.text = "Chargement des catégories…"
        channelAdapter.submit(emptyList(), emptySet())
        vodJob = lifecycleScope.launch {
            try {
                categories = if (m == Mode.MOVIES) Xtream.movieCategories(acc) else Xtream.seriesCategories(acc)
                groupAdapter.submit(categories.map { it.name to -1 }, null)
                status.text = "${categories.size} catégories"
                categories.firstOrNull()?.let { selectCategory(it.name) }
            } catch (e: kotlinx.coroutines.CancellationException) { throw e
            } catch (e: Throwable) {
                status.text = "Catégories indisponibles"
                toast("Erreur serveur : ${e.message}")
            } finally { progress.visibility = View.GONE }
        }
    }

    private fun selectCategory(name: String) {
        val cat = categories.firstOrNull { it.name == name } ?: return
        val acc = account ?: return
        currentCategory = cat
        openedSeries = null
        vodJob?.cancel()
        progress.visibility = View.VISIBLE
        status.text = "${cat.name} · chargement…"
        val m = mode
        vodJob = lifecycleScope.launch {
            try {
                val key = "$m/${cat.id}"
                val items = vodCache[key] ?: (if (m == Mode.MOVIES) Xtream.movies(acc, cat) else Xtream.series(acc, cat))
                    .also { vodCache[key] = it; if (vodCache.size > 20) vodCache.remove(vodCache.keys.first()) }
                vodItems = items
                showVod()
                status.text = "${cat.name} · ${items.size} ${if (m == Mode.MOVIES) "films" else "séries"}"
            } catch (e: kotlinx.coroutines.CancellationException) { throw e
            } catch (e: Throwable) {
                status.text = "${cat.name} · indisponible"
            } finally { progress.visibility = View.GONE }
        }
    }

    private fun openSeries(series: Channel) {
        val acc = account ?: return
        vodJob?.cancel()
        progress.visibility = View.VISIBLE
        status.text = "${series.name} · chargement des épisodes…"
        vodJob = lifecycleScope.launch {
            try {
                val eps = Xtream.episodes(acc, series)
                if (eps.isEmpty()) { toast("Aucun épisode"); return@launch }
                seriesBackup = vodItems
                openedSeries = series
                vodItems = eps
                search.setText("")
                showVod()
                status.text = "${series.name} · ${eps.size} épisodes · Retour pour revenir"
                channelsList.post { channelsList.getChildAt(0)?.requestFocus() }
            } catch (e: kotlinx.coroutines.CancellationException) { throw e
            } catch (e: Throwable) {
                status.text = "${series.name} · épisodes indisponibles"
            } finally { progress.visibility = View.GONE }
        }
    }

    /** @return true si on était dans les épisodes d'une série (et qu'on en sort) */
    private fun closeSeries(): Boolean {
        val s = openedSeries ?: return false
        openedSeries = null
        vodItems = seriesBackup
        showVod()
        status.text = currentCategory?.name ?: ""
        val pos = vodItems.indexOfFirst { it.url == s.url }
        if (pos >= 0) channelsList.post {
            channelsList.scrollToPosition(pos)
            channelsList.post { channelsList.findViewHolderForAdapterPosition(pos)?.itemView?.requestFocus() }
        }
        return true
    }

    /** En mode films/séries, la recherche porte sur la catégorie affichée. */
    private fun showVod() {
        val query = search.text.toString().trim()
        val list = if (query.isEmpty()) vodItems else vodItems.filter { it.name.contains(query, ignoreCase = true) }
        channelAdapter.submit(list, Store.favorites(this))
        channelsList.scrollToPosition(0)
    }

    private fun showChannels() {
        if (mode != Mode.LIVE) { showVod(); return }
        val favs = Store.favorites(this)
        val query = search.text.toString().trim()
        val base = when (currentGroup) {
            Store.ALL -> allChannels
            Store.FAVORITES -> allChannels.filter { it.url in favs }
            else -> allChannels.filter { it.group == currentGroup }
        }
        // La recherche porte sur toutes les chaînes, pas seulement la catégorie
        val list = if (query.isEmpty()) base
                   else allChannels.filter { it.name.contains(query, ignoreCase = true) }
        channelAdapter.submit(list, favs)
        channelsList.scrollToPosition(0)
    }

    private fun focusLastChannel() {
        val last = Store.lastChannelUrl(this) ?: return
        val pos = channelAdapter.items.indexOfFirst { it.url == last }
        if (pos >= 0) channelsList.post {
            channelsList.scrollToPosition(pos)
            channelsList.post { channelsList.findViewHolderForAdapterPosition(pos)?.itemView?.requestFocus() }
        }
    }

    private fun play(pos: Int) {
        Store.currentList = channelAdapter.items
        startActivity(
            Intent(this, PlayerActivity::class.java)
                .putExtra(PlayerActivity.EXTRA_INDEX, pos)
                .putExtra(PlayerActivity.EXTRA_VOD, mode != Mode.LIVE)
        )
    }

    override fun onResume() {
        super.onResume()
        startTicker()
        if (allChannels.isNotEmpty() && mode == Mode.LIVE) {
            refreshGroups()
            showChannels()
            focusLastChannel()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Touche Menu de la télécommande = rafraîchir
        if (keyCode == KeyEvent.KEYCODE_MENU && contentPanel.visibility == View.VISIBLE) {
            vodCache.clear(); load(forceRefresh = true); return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}

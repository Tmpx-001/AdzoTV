package com.adzo.tv

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var setupPanel: View
    private lateinit var contentPanel: View
    private lateinit var urlInput: EditText
    private lateinit var search: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var groupsList: RecyclerView
    private lateinit var channelsList: RecyclerView

    private lateinit var groupAdapter: GroupAdapter
    private lateinit var channelAdapter: ChannelAdapter

    private var allChannels: List<Channel> = emptyList()
    private var currentGroup: String = Store.ALL
    private var epgJob: Job? = null
    private var tickerJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupPanel = findViewById(R.id.setupPanel)
        contentPanel = findViewById(R.id.contentPanel)
        urlInput = findViewById(R.id.urlInput)
        search = findViewById(R.id.search)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        groupsList = findViewById(R.id.groupsList)
        channelsList = findViewById(R.id.channelsList)

        groupAdapter = GroupAdapter { group -> currentGroup = group; showChannels() }
        channelAdapter = ChannelAdapter(
            onClick = { _, pos -> play(pos) },
            onLongClick = { ch, pos ->
                val added = Store.toggleFavorite(this, ch.url)
                channelAdapter.updateFavorites(Store.favorites(this), pos)
                toast(if (added) "Ajoutée aux favoris" else "Retirée des favoris")
                refreshGroups()
            }
        )
        groupsList.layoutManager = LinearLayoutManager(this)
        groupsList.adapter = groupAdapter
        channelsList.layoutManager = LinearLayoutManager(this)
        channelsList.adapter = channelAdapter

        findViewById<Button>(R.id.loadButton).setOnClickListener { submitUrl() }
        urlInput.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE || id == EditorInfo.IME_ACTION_GO) { submitUrl(); true } else false
        }
        findViewById<Button>(R.id.refreshButton).setOnClickListener { load(forceRefresh = true) }
        findViewById<Button>(R.id.settingsButton).setOnClickListener { askChangeUrl() }

        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = showChannels()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })

        if (Store.playlistUrl(this) == null) showSetup() else load(forceRefresh = false)
    }

    // ---------- Écrans ----------

    private fun showSetup() {
        setupPanel.visibility = View.VISIBLE
        contentPanel.visibility = View.GONE
        urlInput.setText(Store.playlistUrl(this) ?: "")
        urlInput.requestFocus()
    }

    private fun submitUrl() {
        val url = urlInput.text.toString().trim()
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            toast("L'adresse doit commencer par http:// ou https://"); return
        }
        Store.setPlaylistUrl(this, url)
        Store.clearCache(this)
        load(forceRefresh = true)
    }

    private fun askChangeUrl() {
        val epg = Store.resolveEpgUrl(this)
        AlertDialog.Builder(this)
            .setTitle("Réglages")
            .setMessage("Playlist :\n${Store.playlistUrl(this)}\n\nGuide des programmes :\n${epg ?: "aucun"}")
            .setPositiveButton("Changer la playlist") { _, _ -> showSetup() }
            .setNeutralButton("Adresse du guide") { _, _ -> askEpgUrl() }
            .setNegativeButton("Fermer", null)
            .show()
    }

    /** Pour les playlists qui n'indiquent pas leur guide : on peut saisir l'URL XMLTV à la main. */
    private fun askEpgUrl() {
        val input = EditText(this).apply {
            setText(Store.manualEpgUrl(this@MainActivity) ?: "")
            hint = "http://…/epg.xml(.gz) — vide = automatique"
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("Adresse du guide (XMLTV)")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                Store.setManualEpgUrl(this, input.text.toString().trim())
                loadEpg(force = true)
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    // ---------- Chargement ----------

    private fun load(forceRefresh: Boolean) {
        val url = Store.playlistUrl(this) ?: return showSetup()
        progress.visibility = View.VISIBLE
        status.text = "Chargement de la playlist…"
        lifecycleScope.launch {
            try {
                allChannels = Store.loadPlaylist(this@MainActivity, url, forceRefresh).channels
                if (allChannels.isEmpty()) {
                    toast("Aucune chaîne trouvée dans ce fichier"); showSetup(); return@launch
                }
                setupPanel.visibility = View.GONE
                contentPanel.visibility = View.VISIBLE
                refreshGroups()
                showChannels()
                status.text = "${allChannels.size} chaînes"
                focusLastChannel()
                loadEpg(forceRefresh)
            } catch (e: Exception) {
                toast("Impossible de charger : ${e.message}")
                showSetup()
            } finally {
                progress.visibility = View.GONE
            }
        }
    }

    // ---------- Guide des programmes ----------

    private fun loadEpg(force: Boolean) {
        val epgUrl = Store.resolveEpgUrl(this) ?: return
        epgJob?.cancel()
        epgJob = lifecycleScope.launch {
            status.text = "${allChannels.size} chaînes · chargement du guide…"
            try {
                val matched = Epg.load(this@MainActivity, epgUrl, allChannels, force)
                status.text = "${allChannels.size} chaînes · guide : $matched"
                channelAdapter.refreshEpg()
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                status.text = "${allChannels.size} chaînes · guide indisponible"
            }
        }
    }

    /** Fait avancer les barres de progression toutes les minutes. */
    private fun startTicker() {
        tickerJob?.cancel()
        tickerJob = lifecycleScope.launch {
            while (isActive) {
                delay(60_000)
                if (Epg.isLoaded) channelAdapter.refreshEpg()
            }
        }
    }

    override fun onPause() {
        super.onPause()
        tickerJob?.cancel()
    }

    private fun refreshGroups() {
        val favs = Store.favorites(this)
        val groups = mutableListOf<Pair<String, Int>>()
        val favCount = allChannels.count { it.url in favs }
        if (favCount > 0) groups += Store.FAVORITES to favCount
        groups += Store.ALL to allChannels.size
        allChannels.groupingBy { it.group }.eachCount()   // garde l'ordre de la playlist
            .forEach { (g, n) -> groups += g to n }
        if (groups.none { it.first == currentGroup }) currentGroup = Store.ALL
        groupAdapter.submit(groups, currentGroup)
    }

    private fun showChannels() {
        val favs = Store.favorites(this)
        val query = search.text.toString().trim()
        val base = when (currentGroup) {
            Store.ALL -> allChannels
            Store.FAVORITES -> allChannels.filter { it.url in favs }
            else -> allChannels.filter { it.group == currentGroup }
        }
        // La recherche porte sur toutes les chaînes, pas seulement la catégorie
        val list = if (query.isEmpty()) base
                   else allChannels.filter { it.name.contains(query, ignoreCase = true) }
        channelAdapter.submit(list, favs)
        channelsList.scrollToPosition(0)
    }

    private fun focusLastChannel() {
        val last = Store.lastChannelUrl(this) ?: return
        val pos = channelAdapter.items.indexOfFirst { it.url == last }
        if (pos >= 0) channelsList.post {
            channelsList.scrollToPosition(pos)
            channelsList.post { channelsList.findViewHolderForAdapterPosition(pos)?.itemView?.requestFocus() }
        }
    }

    private fun play(pos: Int) {
        Store.currentList = channelAdapter.items
        startActivity(Intent(this, PlayerActivity::class.java).putExtra(PlayerActivity.EXTRA_INDEX, pos))
    }

    override fun onResume() {
        super.onResume()
        startTicker()
        if (allChannels.isNotEmpty()) {
            refreshGroups()
            showChannels()
            focusLastChannel()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Touche Menu de la télécommande = rafraîchir
        if (keyCode == KeyEvent.KEYCODE_MENU && contentPanel.visibility == View.VISIBLE) {
            load(forceRefresh = true); return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}

package com.adzo.tv

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_INDEX = "index"
        private const val DEFAULT_UA = Store.USER_AGENT
    }

    private lateinit var playerView: PlayerView
    private lateinit var overlay: TextView
    private lateinit var errorText: TextView
    private var player: ExoPlayer? = null

    private val channels get() = Store.currentList
    private var index = 0
    private var triedHlsFallback = false

    private val handler = Handler(Looper.getMainLooper())
    private val hideOverlay = Runnable { overlay.visibility = View.GONE }
    private var typedNumber = ""
    private val applyTypedNumber = Runnable {
        val n = typedNumber.toIntOrNull()
        typedNumber = ""
        if (n != null && n in 1..channels.size) playIndex(n - 1) else overlay.visibility = View.GONE
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemBars()

        playerView = findViewById(R.id.playerView)
        overlay = findViewById(R.id.overlay)
        errorText = findViewById(R.id.errorText)

        if (channels.isEmpty()) { finish(); return }
        index = intent.getIntExtra(EXTRA_INDEX, 0).coerceIn(channels.indices)
    }

    override fun onStart() {
        super.onStart()
        if (channels.isNotEmpty()) playIndex(index)
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }

    private fun playIndex(i: Int) {
        index = ((i % channels.size) + channels.size) % channels.size // boucle aux extrémités
        triedHlsFallback = false
        val ch = channels[index]
        Store.setLastChannel(this, ch.url)
        showOverlay(channelInfo(ch), 5_000)
        startPlayer(ch, forceHls = false)
    }

    private fun startPlayer(ch: Channel, forceHls: Boolean) {
        releasePlayer()
        errorText.visibility = View.GONE

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(ch.userAgent ?: DEFAULT_UA)
            .setAllowCrossProtocolRedirects(true)   // beaucoup de serveurs redirigent http <-> https
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)

        val item = MediaItem.Builder().setUri(ch.url).apply {
            if (forceHls) setMimeType(MimeTypes.APPLICATION_M3U8)
        }.build()

        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .build().also { p ->
                playerView.player = p
                p.addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) = handleError(ch, error)
                })
                p.setMediaItem(item)
                p.playWhenReady = true
                p.prepare()
            }
    }

    private fun handleError(ch: Channel, error: PlaybackException) {
        when {
            // Le direct a pris trop d'avance : on se recale sur le live
            error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW -> {
                player?.seekToDefaultPosition(); player?.prepare()
            }
            // Flux sans extension .m3u8 qui est en fait du HLS : on retente une fois
            !triedHlsFallback && error.errorCode in listOf(
                PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
                PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED
            ) -> {
                triedHlsFallback = true
                startPlayer(ch, forceHls = true)
            }
            else -> {
                errorText.text = "Lecture impossible : ${error.errorCodeName}\n${ch.name}\n\n↑ / ↓ pour changer de chaîne"
                errorText.visibility = View.VISIBLE
            }
        }
    }

    /** "12 · TF1  /  Maintenant 20:45–22:30  Film…  (35 %)  /  Ensuite 22:30  Magazine" */
    private fun channelInfo(ch: Channel): String = buildString {
        append("${index + 1}  ·  ${ch.name}")
        val (now, next) = Epg.nowNext(ch)
        if (now != null) append("\n▶ ${formatTime(now.start)}–${formatTime(now.stop)}  ${now.title}  (${now.progress()} %)")
        if (next != null) append("\n   Ensuite ${formatTime(next.start)}  ${next.title}")
        now?.desc?.takeIf { it.isNotBlank() }?.let { append("\n\n" + it.take(220) + if (it.length > 220) "…" else "") }
    }

    private fun releasePlayer() {
        player?.release()
        player = null
    }

    private fun showOverlay(text: String, durationMs: Long = 3_000) {
        overlay.text = text
        overlay.visibility = View.VISIBLE
        handler.removeCallbacks(hideOverlay)
        handler.postDelayed(hideOverlay, durationMs)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val controllerVisible = playerView.isControllerFullyVisible
        when (keyCode) {
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> { playIndex(index - 1); return true }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> { playIndex(index + 1); return true }
            KeyEvent.KEYCODE_DPAD_UP -> if (!controllerVisible) { playIndex(index - 1); return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> if (!controllerVisible) { playIndex(index + 1); return true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> if (!controllerVisible) {
                showOverlay(channelInfo(channels[index]), 6_000)
                playerView.showController(); return true
            }
            in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> {
                // Taper un numéro de chaîne comme sur une vraie télé
                typedNumber += (keyCode - KeyEvent.KEYCODE_0).toString()
                showOverlay(typedNumber, 2_000)
                handler.removeCallbacks(applyTypedNumber)
                handler.postDelayed(applyTypedNumber, 1_500)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}

package com.adzo.tv

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * API "Xtream Codes" (player_api.php) : celle qu'utilisent TiviMate, Hot Player, Smarters…
 * On ne charge que la catégorie demandée, donc pas de souci de mémoire même avec 100 000 films.
 */
data class XtreamAccount(val base: String, val user: String, val pass: String)

data class Category(val id: String, val name: String)

object Xtream {

    const val SERIES_SCHEME = "series://"

    /** Déduit le compte à partir d'un lien du type http://serveur:8080/get.php?username=…&password=… */
    fun fromPlaylistUrl(url: String?): XtreamAccount? {
        if (url == null) return null
        val uri = Uri.parse(url)
        val user = uri.getQueryParameter("username") ?: return null
        val pass = uri.getQueryParameter("password") ?: return null
        val path = uri.path ?: return null
        if (!path.endsWith("get.php")) return null
        val base = uri.buildUpon().path(path.removeSuffix("get.php").trimEnd('/')).clearQuery()
            .build().toString().trimEnd('/')
        return XtreamAccount(base, user, pass)
    }

    private fun api(acc: XtreamAccount, action: String, vararg params: Pair<String, String>): String {
        val b = Uri.parse("${acc.base}/player_api.php").buildUpon()
            .appendQueryParameter("username", acc.user)
            .appendQueryParameter("password", acc.pass)
            .appendQueryParameter("action", action)
        params.forEach { (k, v) -> b.appendQueryParameter(k, v) }
        return Store.fetchText(b.build().toString())
    }

    private fun JSONArray.objects(): List<JSONObject> =
        (0 until length()).mapNotNull { optJSONObject(it) }

    private fun JSONObject.str(key: String): String? =
        optString(key, "").takeIf { it.isNotBlank() && it != "null" }

    // ---------- Films ----------

    suspend fun movieCategories(acc: XtreamAccount): List<Category> = withContext(Dispatchers.IO) {
        JSONArray(api(acc, "get_vod_categories")).objects()
            .mapNotNull { o -> Category(o.str("category_id") ?: return@mapNotNull null, o.str("category_name") ?: "Sans nom") }
    }

    suspend fun movies(acc: XtreamAccount, cat: Category): List<Channel> = withContext(Dispatchers.IO) {
        JSONArray(api(acc, "get_vod_streams", "category_id" to cat.id)).objects().mapNotNull { o ->
            val id = o.str("stream_id") ?: return@mapNotNull null
            val ext = o.str("container_extension") ?: "mp4"
            Channel(
                name = o.str("name") ?: "Sans titre",
                url = "${acc.base}/movie/${acc.user}/${acc.pass}/$id.$ext",
                group = cat.name,
                logo = o.str("stream_icon"),
                tvgId = null, userAgent = null
            )
        }
    }

    // ---------- Séries ----------

    suspend fun seriesCategories(acc: XtreamAccount): List<Category> = withContext(Dispatchers.IO) {
        JSONArray(api(acc, "get_series_categories")).objects()
            .mapNotNull { o -> Category(o.str("category_id") ?: return@mapNotNull null, o.str("category_name") ?: "Sans nom") }
    }

    /** Une série est représentée par une "chaîne" dont l'URL est series://<id> */
    suspend fun series(acc: XtreamAccount, cat: Category): List<Channel> = withContext(Dispatchers.IO) {
        JSONArray(api(acc, "get_series", "category_id" to cat.id)).objects().mapNotNull { o ->
            val id = o.str("series_id") ?: return@mapNotNull null
            Channel(
                name = o.str("name") ?: "Sans titre",
                url = SERIES_SCHEME + id,
                group = cat.name,
                logo = o.str("cover"),
                tvgId = null, userAgent = null
            )
        }
    }

    suspend fun episodes(acc: XtreamAccount, series: Channel): List<Channel> = withContext(Dispatchers.IO) {
        val id = series.url.removePrefix(SERIES_SCHEME)
        val root = JSONObject(api(acc, "get_series_info", "series_id" to id))
        val eps = ArrayList<JSONObject>()
        // "episodes" est un objet { "1": [...], "2": [...] } ou parfois un tableau de tableaux
        when (val e = root.opt("episodes")) {
            is JSONObject -> e.keys().forEach { k -> e.optJSONArray(k)?.let { eps += it.objects() } }
            is JSONArray -> (0 until e.length()).forEach { i ->
                when (val s = e.opt(i)) {
                    is JSONArray -> eps += s.objects()
                    is JSONObject -> eps += s
                }
            }
        }
        eps.sortedWith(compareBy({ it.optInt("season") }, { it.optInt("episode_num") })).mapNotNull { o ->
            val epId = o.str("id") ?: return@mapNotNull null
            val ext = o.str("container_extension") ?: "mp4"
            val s = o.optInt("season"); val n = o.optInt("episode_num")
            val title = o.str("title") ?: "Épisode $n"
            Channel(
                name = "S%02dE%02d · %s".format(s, n, title),
                url = "${acc.base}/series/${acc.user}/${acc.pass}/$epId.$ext",
                group = series.name,
                logo = o.optJSONObject("info")?.str("movie_image") ?: series.logo,
                tvgId = null, userAgent = null
            )
        }
    }
}

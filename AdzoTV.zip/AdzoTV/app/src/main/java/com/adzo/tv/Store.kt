package com.adzo.tv

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/** Réglages, favoris, cache de la playlist, et liste en cours (pour zapper dans le lecteur). */
object Store {
    private const val PREFS = "adzo_tv"
    const val FAVORITES = "★ Favoris"
    const val ALL = "Toutes les chaînes"
    const val USER_AGENT = "VLC/3.0.20 LibVLC/3.0.20"

    /** Liste actuellement affichée : le lecteur s'en sert pour zapper avec ↑ / ↓ */
    var currentList: List<Channel> = emptyList()

    /** URL EPG trouvée dans l'en-tête de la playlist (url-tvg) */
    var playlistEpgUrl: String? = null

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun playlistUrl(ctx: Context): String? = prefs(ctx).getString("url", null)
    fun setPlaylistUrl(ctx: Context, url: String?) =
        prefs(ctx).edit().putString("url", url).apply()

    /** URL EPG saisie à la main (prioritaire sur la détection automatique) */
    fun manualEpgUrl(ctx: Context): String? = prefs(ctx).getString("epg", null)?.takeIf { it.isNotBlank() }
    fun setManualEpgUrl(ctx: Context, url: String?) = prefs(ctx).edit().putString("epg", url).apply()

    /**
     * Ordre de priorité : URL manuelle > url-tvg de la playlist > xmltv.php des serveurs Xtream.
     */
    fun resolveEpgUrl(ctx: Context): String? {
        manualEpgUrl(ctx)?.let { return it }
        playlistEpgUrl?.let { return it }
        val pl = playlistUrl(ctx) ?: return null
        val uri = Uri.parse(pl)
        val user = uri.getQueryParameter("username")
        val pass = uri.getQueryParameter("password")
        if (uri.path?.endsWith("get.php") == true && user != null && pass != null) {
            return uri.buildUpon().path(uri.path!!.removeSuffix("get.php") + "xmltv.php")
                .clearQuery()
                .appendQueryParameter("username", user)
                .appendQueryParameter("password", pass)
                .build().toString()
        }
        return null
    }

    fun lastChannelUrl(ctx: Context): String? = prefs(ctx).getString("last", null)
    fun setLastChannel(ctx: Context, url: String) = prefs(ctx).edit().putString("last", url).apply()

    fun favorites(ctx: Context): Set<String> =
        prefs(ctx).getStringSet("favs", emptySet())!!.toSet()

    fun toggleFavorite(ctx: Context, url: String): Boolean {
        val favs = favorites(ctx).toMutableSet()
        val added = favs.add(url) || run { favs.remove(url); false }
        prefs(ctx).edit().putStringSet("favs", favs).apply()
        return added
    }

    private fun cacheFile(ctx: Context) = File(ctx.filesDir, "playlist.m3u")

    /** Télécharge la playlist (et la met en cache). Si le réseau échoue, retombe sur le cache. */
    suspend fun loadPlaylist(ctx: Context, url: String, forceRefresh: Boolean): Playlist =
        withContext(Dispatchers.IO) {
            val cache = cacheFile(ctx)
            if (forceRefresh || !cache.exists() || cache.length() == 0L) {
                val tmp = File(ctx.filesDir, "playlist.tmp")
                try {
                    downloadTo(url, tmp)
                    tmp.renameTo(cache)
                } catch (e: Exception) {
                    tmp.delete()
                    if (!cache.exists()) throw e
                }
            }
            cache.bufferedReader().useLines { M3uParser.parse(it) }.also { playlistEpgUrl = it.epgUrl }
        }

    fun clearCache(ctx: Context) {
        cacheFile(ctx).delete()
        Epg.clearCache(ctx)
    }

    /** Téléchargement en flux vers un fichier (les guides EPG font souvent plusieurs dizaines de Mo). */
    fun downloadTo(url: String, dest: File) {
        openStream(url).use { input -> dest.outputStream().use { input.copyTo(it, 64 * 1024) } }
    }

    fun fetchText(url: String): String = openStream(url).bufferedReader().use { it.readText() }

    private fun openStream(url: String): InputStream {
        var current = url
        repeat(5) { // suit les redirections, y compris http <-> https
            val conn = (URL(current).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 60_000
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", USER_AGENT)
            }
            when (val code = conn.responseCode) {
                in 300..399 -> {
                    current = URL(URL(current), conn.getHeaderField("Location")).toString()
                    conn.disconnect()
                }
                in 200..299 -> return conn.inputStream
                else -> { conn.disconnect(); throw Exception("Erreur HTTP $code") }
            }
        }
        throw Exception("Trop de redirections")
    }
}

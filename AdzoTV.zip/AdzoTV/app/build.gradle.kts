plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.adzo.tv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.adzo.tv"
        minSdk = 21
        targetSdk = 34
        // Numéro de build GitHub = numéro de version (sinon 1 en local)
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "1.0." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
    }

    // Clé de signature fixe (versionnée) : chaque APK compilé par GitHub peut
    // s'installer PAR-DESSUS le précédent sans désinstaller l'appli.
    signingConfigs {
        create("adzo") {
            storeFile = file("adzo-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug { signingConfig = signingConfigs.getByName("adzo") }
        release {
            isMinifyEnabled = false
            // Signe la release avec la clé debug : pratique pour un usage perso (sideload)
            signingConfig = signingConfigs.getByName("adzo")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { viewBinding = false }
    // Appli perso, pas publiée sur le Play Store : on ne bloque pas le build sur les alertes lint
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    val media3 = "1.4.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-ui:$media3")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("io.coil-kt:coil:2.6.0")
}

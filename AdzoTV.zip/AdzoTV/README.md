# ADZO TV — lecteur M3U pour Android TV

## Installer
1. Ouvre le dossier `AdzoTV` dans **Android Studio** (File > Open). Il télécharge Gradle et les dépendances tout seul.
2. Sur ta box/TV : Paramètres > Préférences de l'appareil > À propos > clique 7 fois sur « Version » → Options développeur > active **Débogage USB / ADB**.
3. Connecte-toi en Wi-Fi : `adb connect IP_DE_LA_TV:5555`, puis bouton ▶ Run dans Android Studio.
   Ou : Build > Build APK(s), puis installe l'APK via « Send Files to TV » / clé USB.

## Utilisation
- Au premier lancement, colle l'URL de ta playlist M3U (tape-la sur ton téléphone avec l'appli Google TV pour aller plus vite).
- Catégories à gauche, chaînes à droite, recherche en haut.
- **OK** : regarder · **appui long sur OK** : favori
- Dans le lecteur : **↑ / ↓** ou **CH+ / CH-** pour zapper, **chiffres** pour taper un numéro, **Retour** pour revenir à la liste.
- La playlist est gardée en cache : bouton « Actualiser » (ou touche Menu) pour la recharger.

## Guide des programmes (EPG)
- Trouvé automatiquement : `url-tvg` dans l'en-tête de la playlist, ou `xmltv.php` pour les serveurs Xtream (URL en `get.php?username=…&password=…`).
- Sinon : ⚙ Réglages > « Adresse du guide », colle une URL XMLTV (.xml ou .xml.gz).
- Le guide est mis en cache et retéléchargé toutes les 12 h (ou avec « Actualiser »).
- Les chaînes sont reliées au guide par leur `tvg-id`, ou à défaut par leur nom (« FR: TF1 FHD » = « TF1 »).
- Dans la liste : programme en cours + barre de progression. Dans le lecteur : OK affiche Maintenant / Ensuite + résumé.
